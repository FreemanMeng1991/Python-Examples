import os
root_path = os.getcwd()
offset = len(root_path.split("\\"))
print(offset)
print(root_path)
filename     = []
indent_level = []
#print(os.path.dirname(root_path),"\n")

for root,dirs,files in os.walk(root_path):
    #print("Current : ",root)
    parent_dir = root.split("\\")
    level = len(parent_dir)-offset
    
    #print("Level   : ",level)
    indent_level.append(level)
    filename.append("\\"+parent_dir[-1])
    #structure[parent_dir[-1]] = level
    for f in files:
    	#structure[f] = level+1
    	indent_level.append(level+1)
    	filename.append(f)
    #print("SubDirs : ",dirs,"\n")
    for file in files:
        abspath = os.path.join(root,file)
        
        #print("Abspath : ",abspath)
        #print("Filename: ",os.path.splitext(file)[0])
        #print("Type    : ",os.path.splitext(file)[1])
        #print("Size    : ",os.path.getsize(abspath),"\n")
print(filename)
print(indent_level)

'''
for k,v in structure.items():
	print("\t"*v,k,v)
'''

for f,i in zip(filename,indent_level):
	print("\t"*i,f)
	