import os
import xlrd
root_path = os.getcwd() #获取当前根目录的路径
offset = len(root_path.split("\\"))
class_data = []
counter = 0

for root,dirs,files in os.walk(root_path):
	if len(root.split("\\"))-offset > 1:
		pass
	else:
		department = root.split("\\")[-1]

	for f in files:
		class_descriptor = []
		if(f.startswith("~$") or not f.endswith(('.xls','.xlsx'))):
			pass
		else:
			data  = xlrd.open_workbook("\\".join([root,f]))
			sheet_name = data.sheet_names()[0] #获取工作簿中的第一个工作表名
			table = data.sheet_by_name(sheet_name)	
			
			#获取Excel第二行全部单元格内容并合并成一个字符串
			table_header = "".join(table.row_values(1)) 
			class_name = table_header[table_header.find("班级：")+3:table_header.find("课程")].strip()
			col_data = table.col_values
			student_ids = (col_data(2,5,-5)+col_data(10,5,-5))
			student_names = (col_data(3,5,-5)+col_data(11,5,-5))
			
			with open(class_name+'.txt','w') as fp:
				counter = 0
				for s_id, s_name in zip(student_ids,student_names):
					if type(s_id) == float:
						fp.write("\t".join([str(s_id)[:-2],s_name,"\n"]))
						counter+=1
					elif len(s_id) == 0:
						pass
					else:
						fp.write("\t".join([s_id,s_name,"\n"]))
						counter+=1
				#print(department,class_name,counter)
				class_descriptor.extend([department,class_name,counter])
				class_data.append(class_descriptor)

prev = class_data[0][0]
print(format(prev,"-^60"))
for i in class_data:
	if i[0] != prev:
		prev = i[0]
		print(format(prev,"-^60"))
	print(i[1],i[2])
